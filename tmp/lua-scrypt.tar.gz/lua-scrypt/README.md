lua-scrypt
==========

Lua (actually C) scrypt-library for OpenResty (lua-resty-scrypt).
