:man_page: mongoc_init

mongoc_init()
=============

Synopsis
--------

.. code-block:: c

  void
  mongoc_init (void);

Description
-----------

.. include:: includes/init_cleanup.txt
