:man_page: mongoc_session_opts_destroy

mongoc_session_opts_destroy()
=============================

Synopsis
--------

.. code-block:: c

  void
  mongoc_session_opts_destroy (mongoc_session_opt_t *opts);

Free a :symbol:`mongoc_session_opt_t`.

See the example code for :symbol:`mongoc_session_opts_set_causal_consistency`.

.. only:: html

  .. taglist:: See Also:
    :tags: session
